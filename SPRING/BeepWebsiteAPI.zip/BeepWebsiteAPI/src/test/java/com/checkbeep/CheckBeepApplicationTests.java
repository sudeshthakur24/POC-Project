package com.checkbeep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckBeepApplicationTests {

	@Test
	void contextLoads() {
	}

}
